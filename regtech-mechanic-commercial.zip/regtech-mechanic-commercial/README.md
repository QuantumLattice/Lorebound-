# RegTech Mechanic

A GitHub-ready workshop web app for identifying UK vehicles by registration and giving mechanics a fast route into vehicle-specific diagnostic information.

## What is included

- Registration lookup UI designed for workshop use
- Official DVLA Vehicle Enquiry Service backend integration
- Safe server-side API key handling (the key is never exposed to the browser)
- Optional enrichment adapter for exact model / derivative data
- Built-in demo vehicles so the project works before an API key is added
- Responsive desktop/tablet/mobile interface
- Searchable diagnostic categories and guided fault-finding starter content
- Production build served from the included Express server

## Important data limitation

The official DVLA Vehicle Enquiry API returns fields such as make, registration, manufacture year, engine capacity, fuel type, tax/MOT status, colour, revenue weight and Euro status. Its documented response does not include the exact commercial model/derivative.

RegTech Mechanic therefore supports a second enrichment endpoint. This means you can connect a licensed vehicle-data provider later without changing the frontend.

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

Open `http://localhost:4173`.

Without a `DVLA_API_KEY`, the app uses demo mode. Try:

- `YN19 KBU` – Scania R450 demo
- `AB12 CDE` – Ford Transit demo

## Connect DVLA

1. Register for the DVLA Vehicle Enquiry Service API and obtain an API key.
2. Put the key in your local `.env` file:

```env
DVLA_API_KEY=your_key_here
```

The server calls:

```text
POST https://driver-vehicle-licensing.api.gov.uk/vehicle-enquiry/v1/vehicles
```

with the key in the `x-api-key` request header.

Never commit `.env` or expose the DVLA key in frontend JavaScript.

## Add exact model data

Configure an enrichment service in `.env`:

```env
VEHICLE_ENRICHMENT_URL=https://your-provider-or-adapter.example/lookup
VEHICLE_ENRICHMENT_TOKEN=optional_bearer_token
```

RegTech Mechanic will POST:

```json
{
  "registrationNumber": "YN19KBU",
  "dvla": { "make": "SCANIA", "yearOfManufacture": 2019 }
}
```

Your adapter can respond with any extra fields, for example:

```json
{
  "model": "R450",
  "derivative": "6x2 Highline",
  "bodyType": "Tractor unit",
  "transmission": "Opticruise"
}
```

These values are merged into the vehicle record returned to the browser.

## Production

```bash
npm run build
npm start
```

The project can be pushed directly to GitHub and deployed to any Node-capable host (for example Render, Railway, Fly.io, a VPS, or a container platform). Static-only GitHub Pages cannot securely host the DVLA API key, so live vehicle lookup needs a backend/serverless host.

## Suggested next integrations

The UI and API layer are intentionally separated so you can add:

- manufacturer workshop-manual links by make/model
- DTC code databases
- wiring diagrams
- service schedules and fluid capacities
- torque specifications
- parts catalogues
- technician notes / saved jobs
- authentication and workshop accounts
- scan-tool or telematics imports

## Safety

The diagnostic guides are workflow prompts, not substitutes for current manufacturer workshop procedures. Always verify repair specifications, isolation procedures, lifting requirements, torque values and roadworthiness criteria for the exact vehicle being worked on.

## iPhone / iPad deployment

This repository now includes Vercel serverless endpoints in `api/` and `vercel.json`, so the frontend and private DVLA lookup can be deployed together without exposing API credentials in browser code.

For the iOS-only workflow, see [`IPHONE_UPLOAD_GUIDE.md`](./IPHONE_UPLOAD_GUIDE.md).
