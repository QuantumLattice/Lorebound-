const demoVehicles = {
  YN19KBU: {
    registrationNumber: 'YN19 KBU',
    make: 'SCANIA',
    model: 'R450',
    derivative: '6x2 Highline',
    yearOfManufacture: 2019,
    fuelType: 'DIESEL',
    engineCapacity: 12742,
    colour: 'WHITE',
    revenueWeight: 44000,
    euroStatus: 'Euro 6',
    motStatus: 'Valid',
    motExpiryDate: '2027-03-18',
    taxStatus: 'Taxed',
    source: 'demo'
  },
  AB12CDE: {
    registrationNumber: 'AB12 CDE',
    make: 'FORD',
    model: 'Transit',
    derivative: '350 L3H2',
    yearOfManufacture: 2018,
    fuelType: 'DIESEL',
    engineCapacity: 1995,
    colour: 'SILVER',
    revenueWeight: 3500,
    euroStatus: 'Euro 6',
    motStatus: 'Valid',
    motExpiryDate: '2027-01-23',
    taxStatus: 'Taxed',
    source: 'demo'
  }
};

export function normaliseRegistration(value = '') {
  return String(value).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
}

export async function fetchDvla(registrationNumber) {
  const apiKey = process.env.DVLA_API_KEY;
  if (!apiKey) return null;

  const response = await fetch('https://driver-vehicle-licensing.api.gov.uk/vehicle-enquiry/v1/vehicles', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'x-api-key': apiKey,
      'X-Correlation-Id': crypto.randomUUID()
    },
    body: JSON.stringify({ registrationNumber })
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload?.errors?.[0]?.detail || 'Vehicle lookup failed');
    error.status = response.status;
    throw error;
  }

  return { ...payload, source: 'dvla' };
}

export async function enrichVehicle(registrationNumber, dvla) {
  if (!process.env.VEHICLE_ENRICHMENT_URL) return {};

  const headers = { 'Content-Type': 'application/json', Accept: 'application/json' };
  if (process.env.VEHICLE_ENRICHMENT_TOKEN) {
    headers.Authorization = `Bearer ${process.env.VEHICLE_ENRICHMENT_TOKEN}`;
  }

  const response = await fetch(process.env.VEHICLE_ENRICHMENT_URL, {
    method: 'POST',
    headers,
    body: JSON.stringify({ registrationNumber, dvla })
  });

  if (!response.ok) return {};
  const payload = await response.json().catch(() => ({}));
  return payload && typeof payload === 'object' ? payload : {};
}

export async function getVehicle(registrationNumber) {
  let vehicle = await fetchDvla(registrationNumber);

  if (!vehicle) {
    vehicle = demoVehicles[registrationNumber] || {
      ...demoVehicles.YN19KBU,
      registrationNumber,
      model: 'Model enrichment required',
      derivative: 'Connect a model-data provider',
      source: 'demo'
    };
  }

  const enrichment = await enrichVehicle(registrationNumber, vehicle);
  return { ...vehicle, ...enrichment };
}
