import { getVehicle, normaliseRegistration } from './_vehicle-data.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  const registrationNumber = normaliseRegistration(req.body?.registrationNumber);
  if (registrationNumber.length < 2) {
    return res.status(400).json({ error: 'Enter a valid registration number.' });
  }

  try {
    const vehicle = await getVehicle(registrationNumber);
    return res.status(200).json(vehicle);
  } catch (error) {
    return res.status(error.status || 500).json({
      error: error.message || 'Unable to identify vehicle.'
    });
  }
}
