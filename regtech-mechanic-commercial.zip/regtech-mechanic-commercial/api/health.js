export default function handler(_req, res) {
  return res.status(200).json({
    ok: true,
    dvlaConfigured: Boolean(process.env.DVLA_API_KEY)
  });
}
