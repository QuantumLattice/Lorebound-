# Publish RegTech Mechanic from an iPhone

This edition is set up so the React site and its private vehicle-lookup API can both be deployed to Vercel.

## Easiest iPhone route: GitHub + Working Copy + Vercel

1. In the iPhone **Files** app, tap the downloaded `regtech-mechanic-ios-github.zip` to unzip it.
2. Install **Working Copy** from the App Store and connect it to your GitHub account.
3. In Working Copy, create a new repository and import the unzipped RegTech Mechanic folder.
4. Commit all files, create a GitHub remote, then push the `main` branch.
5. In Safari, open Vercel and sign in with GitHub.
6. Choose **Add New → Project**, select the RegTech Mechanic GitHub repository and deploy it.
7. The demo vehicle lookup works immediately.
8. For live DVLA data, open the Vercel project → **Settings → Environment Variables** and add:
   - `DVLA_API_KEY` = your DVLA Vehicle Enquiry Service API key
9. Redeploy after adding the key.

## Optional exact-model provider

DVLA's Vehicle Enquiry response does not provide the exact model/derivative. If you later subscribe to a compatible model-data provider, add these Vercel environment variables:

- `VEHICLE_ENRICHMENT_URL`
- `VEHICLE_ENRICHMENT_TOKEN` (only if your provider requires it)

The serverless API will merge that provider's model information into the DVLA vehicle record.

## GitHub repository settings

The repository root should contain `package.json`, `index.html`, `src/`, `api/`, and `vercel.json`. Do not upload the outer folder as a single ZIP file into GitHub and expect GitHub to unpack it.

## Demo registration plates

- `YN19 KBU` — Scania R450 demo
- `AB12 CDE` — Ford Transit demo

## Security

Never add the real DVLA API key to `.env.example`, source code, or GitHub. Store it only as a Vercel environment variable (or a local `.env` file that is ignored by Git).
