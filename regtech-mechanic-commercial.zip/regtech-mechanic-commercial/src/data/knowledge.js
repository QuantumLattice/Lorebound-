import {
  Activity,
  BatteryCharging,
  CircleGauge,
  Disc3,
  Gauge,
  Settings2,
  ShieldAlert,
  Thermometer,
  Wrench
} from 'lucide-react';

export const diagnosticCategories = [
  {
    id: 'engine',
    title: 'Engine',
    icon: Settings2,
    description: 'Starting, power, smoke, cooling and lubrication faults',
    accent: 'amber'
  },
  {
    id: 'electrical',
    title: 'Electrical',
    icon: BatteryCharging,
    description: 'Batteries, charging, CAN, sensors and wiring',
    accent: 'blue'
  },
  {
    id: 'brakes',
    title: 'Brakes',
    icon: Disc3,
    description: 'Air systems, EBS/ABS, wear and imbalance',
    accent: 'red'
  },
  {
    id: 'transmission',
    title: 'Transmission',
    icon: Gauge,
    description: 'Clutch, gearbox, shift quality and driveline',
    accent: 'purple'
  },
  {
    id: 'emissions',
    title: 'Emissions',
    icon: Activity,
    description: 'DPF, SCR, AdBlue, NOx and exhaust aftertreatment',
    accent: 'green'
  },
  {
    id: 'inspection',
    title: 'Inspection',
    icon: ShieldAlert,
    description: 'Workshop checks, roadworthiness and service planning',
    accent: 'slate'
  }
];

export const articles = [
  {
    id: 'low-power',
    category: 'engine',
    title: 'Low power under load',
    summary: 'A structured first-pass diagnostic path for reduced engine performance.',
    symptoms: ['Poor acceleration', 'Low boost', 'High fuel use'],
    steps: [
      'Confirm the complaint under safe, repeatable conditions and record active fault codes.',
      'Compare requested versus actual boost/fuel pressure values using approved diagnostic software.',
      'Inspect intake pipework, charge-air connections and filter restriction before replacing components.',
      'Check exhaust restriction and aftertreatment status if boost and fuelling commands appear normal.',
      'Use manufacturer test limits before condemning turbocharger, injectors or high-pressure fuel components.'
    ]
  },
  {
    id: 'no-crank',
    category: 'electrical',
    title: 'No crank / intermittent start',
    summary: 'Battery-to-starter checks that avoid unnecessary parts replacement.',
    symptoms: ['Click but no crank', 'Slow crank', 'Intermittent start'],
    steps: [
      'Verify battery state of charge and inspect battery connections before load testing.',
      'Measure voltage drop across positive and ground paths during a crank request.',
      'Check starter control command, relays and interlocks using the correct wiring information.',
      'Inspect network or immobiliser faults if starter hardware tests correctly but no command is present.'
    ]
  },
  {
    id: 'air-pressure',
    category: 'brakes',
    title: 'Slow air pressure build-up',
    summary: 'A safe route through compressor, leakage and air-treatment checks.',
    symptoms: ['Warning remains on', 'Slow gauge rise', 'Frequent compressor cycling'],
    steps: [
      'Chock the vehicle and follow the manufacturer procedure before working on compressed-air systems.',
      'Check for audible leakage and review system pressure data where available.',
      'Inspect compressor intake, delivery line, dryer and governor/unloader operation.',
      'Use specified build-up time and cut-in/cut-out limits before replacing the compressor or air dryer.'
    ]
  },
  {
    id: 'shift-quality',
    category: 'transmission',
    title: 'Poor automated gear shifts',
    summary: 'Separate clutch wear, actuator, air-supply and calibration issues.',
    symptoms: ['Harsh shifts', 'Gear unavailable', 'Clutch warning'],
    steps: [
      'Read gearbox and vehicle management fault codes before carrying out adjustments.',
      'Verify supply voltage and air pressure where the transmission uses pneumatic actuation.',
      'Check clutch wear/adaptation values and actuator travel against manufacturer limits.',
      'Only run calibration routines when prerequisites such as temperature, pressure and battery support are satisfied.'
    ]
  },
  {
    id: 'scr',
    category: 'emissions',
    title: 'SCR / AdBlue efficiency fault',
    summary: 'Work from fluid quality and dosing to NOx conversion evidence.',
    symptoms: ['Emissions warning', 'Derate', 'High NOx conversion fault'],
    steps: [
      'Read the complete fault-code set and freeze-frame data; secondary faults often explain SCR complaints.',
      'Check AdBlue level/quality, crystallisation, leaks and dosing-system pressure using approved procedures.',
      'Compare upstream/downstream NOx sensor behaviour during the specified test routine.',
      'Confirm exhaust temperature conditions and rule out upstream combustion or DPF problems before condemning the SCR catalyst.'
    ]
  },
  {
    id: 'overheat',
    category: 'engine',
    title: 'Engine overheating',
    summary: 'Cooling-system diagnosis from basic airflow checks to controlled pressure testing.',
    symptoms: ['High coolant temp', 'Fan running continuously', 'Coolant loss'],
    steps: [
      'Allow the system to cool before opening any pressurised cooling circuit.',
      'Inspect coolant level, concentration, visible leakage and radiator/intercooler airflow restriction.',
      'Compare commanded and actual fan operation plus coolant temperature sensor plausibility.',
      'Pressure-test only to the manufacturer limit and investigate combustion-gas intrusion if unexplained pressure rise persists.'
    ]
  },
  {
    id: 'inspection',
    category: 'inspection',
    title: 'Pre-service inspection workflow',
    summary: 'A repeatable vehicle walk-around before deeper diagnostics.',
    symptoms: ['Scheduled service', 'New vehicle intake', 'Repeat defect prevention'],
    steps: [
      'Record registration, mileage/hours, warning lamps and driver-reported concerns.',
      'Inspect tyres, lighting, mirrors, fluids, visible leaks, steering/suspension and braking components.',
      'Run a full-system diagnostic scan before clearing any faults.',
      'Record defects with severity, supporting evidence and the source of any repair specification used.'
    ]
  }
];

export const quickStats = [
  { label: 'Systems', value: '6', icon: Wrench },
  { label: 'Guided checks', value: '7', icon: CircleGauge },
  { label: 'Safety prompts', value: 'Built-in', icon: Thermometer }
];
