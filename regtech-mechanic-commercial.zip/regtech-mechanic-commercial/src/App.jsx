import React, { useMemo, useState } from 'react';
import {
  BookOpenText,
  ChevronRight,
  CircleHelp,
  Database,
  Gauge,
  History,
  Home,
  Menu,
  Search,
  ShieldCheck,
  Sparkles,
  Truck,
  Wrench,
  X
} from 'lucide-react';
import { articles, diagnosticCategories } from './data/knowledge';

const demoVehicle = {
  registrationNumber: 'YN19 KBU',
  make: 'SCANIA',
  model: 'R450',
  derivative: '6x2 Highline',
  yearOfManufacture: 2019,
  fuelType: 'DIESEL',
  engineCapacity: 12742,
  colour: 'WHITE',
  revenueWeight: 44000,
  euroStatus: 'Euro 6',
  motStatus: 'Valid',
  motExpiryDate: '2027-03-18',
  taxStatus: 'Taxed',
  source: 'demo'
};

function formatCc(value) {
  if (!value) return '—';
  if (value >= 10000) return `${(value / 1000).toFixed(1)} L`;
  return `${Number(value).toLocaleString('en-GB')} cc`;
}

function formatWeight(value) {
  return value ? `${Number(value).toLocaleString('en-GB')} kg` : '—';
}

function Plate({ value }) {
  const formatted = String(value || '').toUpperCase();
  return (
    <div className="plate" aria-label={`Registration ${formatted}`}>
      <span className="plate-band">UK</span>
      <strong>{formatted}</strong>
    </div>
  );
}

function App() {
  const [registration, setRegistration] = useState('YN19 KBU');
  const [vehicle, setVehicle] = useState(demoVehicle);
  const [selectedCategory, setSelectedCategory] = useState('engine');
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const visibleArticles = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return articles.filter((article) => {
      const categoryMatch = selectedCategory === 'all' || article.category === selectedCategory;
      const searchMatch = !needle || `${article.title} ${article.summary} ${article.symptoms.join(' ')}`.toLowerCase().includes(needle);
      return categoryMatch && searchMatch;
    });
  }, [selectedCategory, query]);

  async function lookupVehicle(event) {
    event?.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await fetch('/api/vehicle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ registrationNumber: registration })
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || 'Vehicle lookup failed');
      setVehicle(payload);
    } catch (lookupError) {
      setError(lookupError.message);
    } finally {
      setLoading(false);
    }
  }

  const nav = [
    { label: 'Vehicle lookup', icon: Home, active: true },
    { label: 'Diagnostics', icon: Gauge },
    { label: 'Knowledge base', icon: BookOpenText },
    { label: 'Recent vehicles', icon: History }
  ];

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><Wrench size={20} /></div>
          <div><strong>RegTech Mechanic</strong><span>Vehicle identification & diagnostics</span></div>
          <button className="icon-button mobile-only" onClick={() => setSidebarOpen(false)}><X size={20} /></button>
        </div>

        <nav className="nav-list">
          {nav.map((item) => (
            <button key={item.label} className={`nav-item ${item.active ? 'active' : ''}`}>
              <item.icon size={18} /><span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-card">
          <div className="sidebar-card-icon"><ShieldCheck size={18} /></div>
          <strong>Workshop-safe by design</strong>
          <p>Use OEM procedures and approved specifications before carrying out repairs.</p>
        </div>

        <div className="sidebar-footer">
          <span className="status-dot" /> Vehicle data adapter ready
        </div>
      </aside>

      {sidebarOpen && <button className="backdrop" onClick={() => setSidebarOpen(false)} aria-label="Close menu" />}

      <main className="main-content">
        <header className="topbar">
          <button className="icon-button mobile-only" onClick={() => setSidebarOpen(true)}><Menu size={21} /></button>
          <div className="topbar-title"><span>Workshop</span><ChevronRight size={15} /><strong>Vehicle lookup</strong></div>
          <div className="top-actions">
            <button className="icon-button"><CircleHelp size={19} /></button>
            <div className="user-chip">MT</div>
          </div>
        </header>

        <section className="hero-section">
          <div className="eyebrow"><Sparkles size={14} /> FAST VEHICLE IDENTIFICATION</div>
          <h1>Find the vehicle. Find the fault.<br /><span>Get to the fix faster.</span></h1>
          <p className="hero-copy">Enter a UK registration to identify the vehicle, then move straight into structured diagnostic information and workshop checks.</p>

          <form className="lookup-card" onSubmit={lookupVehicle}>
            <div className="lookup-label">Vehicle registration</div>
            <div className="lookup-row">
              <div className="reg-input-wrap">
                <span className="uk-band">UK</span>
                <input
                  value={registration}
                  onChange={(e) => setRegistration(e.target.value.toUpperCase())}
                  placeholder="AB12 CDE"
                  aria-label="Vehicle registration"
                />
              </div>
              <button className="primary-button" disabled={loading}>
                <Search size={19} /> {loading ? 'Looking up…' : 'Identify vehicle'}
              </button>
            </div>
            <div className="lookup-hint">Demo registrations: <button type="button" onClick={() => setRegistration('YN19 KBU')}>YN19 KBU</button> or <button type="button" onClick={() => setRegistration('AB12 CDE')}>AB12 CDE</button></div>
            {error && <div className="error-message">{error}</div>}
          </form>
        </section>

        <section className="vehicle-card">
          <div className="vehicle-identity">
            <div className="vehicle-icon"><Truck size={31} /></div>
            <div className="vehicle-heading">
              <div className="vehicle-title-row">
                <h2>{vehicle.make} <span>{vehicle.model || 'Model data unavailable'}</span></h2>
                <span className={`source-badge ${vehicle.source === 'dvla' ? 'live' : ''}`}>{vehicle.source === 'dvla' ? 'LIVE DATA' : 'DEMO'}</span>
              </div>
              <p>{vehicle.derivative || `${vehicle.yearOfManufacture || 'Unknown year'} • ${vehicle.fuelType || 'Fuel type unavailable'}`}</p>
            </div>
            <Plate value={vehicle.registrationNumber || registration} />
          </div>

          <div className="spec-grid">
            <div><span>Year</span><strong>{vehicle.yearOfManufacture || '—'}</strong></div>
            <div><span>Engine</span><strong>{formatCc(vehicle.engineCapacity)}</strong></div>
            <div><span>Fuel</span><strong>{vehicle.fuelType || '—'}</strong></div>
            <div><span>Euro status</span><strong>{vehicle.euroStatus || '—'}</strong></div>
            <div><span>Revenue weight</span><strong>{formatWeight(vehicle.revenueWeight)}</strong></div>
            <div><span>Colour</span><strong>{vehicle.colour || '—'}</strong></div>
            <div><span>MOT</span><strong className={vehicle.motStatus === 'Valid' ? 'ok-text' : ''}>{vehicle.motStatus || '—'}</strong></div>
            <div><span>Tax</span><strong className={vehicle.taxStatus === 'Taxed' ? 'ok-text' : ''}>{vehicle.taxStatus || '—'}</strong></div>
          </div>

          {(!vehicle.model || vehicle.model.includes('enrichment')) && (
            <div className="enrichment-note"><Database size={16} /> Exact model/derivative needs a compatible enrichment provider; the backend already includes the adapter hook.</div>
          )}
        </section>

        <section className="workspace-section">
          <div className="section-heading">
            <div><span className="section-kicker">DIAGNOSTIC LIBRARY</span><h2>What are you working on?</h2></div>
            <div className="library-search"><Search size={17} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search symptoms or systems" /></div>
          </div>

          <div className="category-grid">
            {diagnosticCategories.map((category) => (
              <button key={category.id} onClick={() => setSelectedCategory(category.id)} className={`category-card ${selectedCategory === category.id ? 'selected' : ''}`}>
                <div className={`category-icon ${category.accent}`}><category.icon size={22} /></div>
                <strong>{category.title}</strong>
                <span>{category.description}</span>
                <ChevronRight className="category-arrow" size={18} />
              </button>
            ))}
          </div>

          <div className="content-layout">
            <div className="guide-list">
              <div className="guide-list-heading">
                <div><span>GUIDED CHECKS</span><h3>{diagnosticCategories.find(c => c.id === selectedCategory)?.title || 'All systems'}</h3></div>
                <button className="text-button" onClick={() => setSelectedCategory('all')}>View all</button>
              </div>

              {visibleArticles.length ? visibleArticles.map((article) => (
                <button key={article.id} className={`guide-item ${selectedArticle?.id === article.id ? 'active' : ''}`} onClick={() => setSelectedArticle(article)}>
                  <div className="guide-number">{String(articles.indexOf(article) + 1).padStart(2, '0')}</div>
                  <div className="guide-copy">
                    <strong>{article.title}</strong>
                    <p>{article.summary}</p>
                    <div className="symptom-tags">{article.symptoms.map(s => <span key={s}>{s}</span>)}</div>
                  </div>
                  <ChevronRight size={19} />
                </button>
              )) : <div className="empty-state">No matching diagnostic guides.</div>}
            </div>

            <aside className="diagnostic-panel">
              {selectedArticle ? (
                <>
                  <div className="panel-top"><span>DIAGNOSTIC PATH</span><button className="icon-button" onClick={() => setSelectedArticle(null)}><X size={18} /></button></div>
                  <h3>{selectedArticle.title}</h3>
                  <p className="panel-summary">{selectedArticle.summary}</p>
                  <ol className="step-list">
                    {selectedArticle.steps.map((step, index) => (
                      <li key={step}><span>{index + 1}</span><p>{step}</p></li>
                    ))}
                  </ol>
                  <div className="safety-note"><ShieldCheck size={17} /><p><strong>Before repair:</strong> verify torque values, test limits and procedures against current manufacturer information for this exact vehicle.</p></div>
                </>
              ) : (
                <div className="panel-placeholder">
                  <div className="placeholder-icon"><Wrench size={28} /></div>
                  <h3>Select a diagnostic guide</h3>
                  <p>Choose a system or symptom to open a structured fault-finding path here.</p>
                </div>
              )}
            </aside>
          </div>
        </section>

        <footer>
          RegTech Mechanic is a diagnostic support tool. Always follow manufacturer workshop information, safe isolation procedures and applicable roadworthiness requirements.
        </footer>
      </main>
    </div>
  );
}

export default App;
